#ifndef _GLSLCOOKBOOK_OGL
#define _GLSLCOOKBOOK_OGL

#include <glad/glad.h>

#define GLM_FORCE_RADIANS

#endif
